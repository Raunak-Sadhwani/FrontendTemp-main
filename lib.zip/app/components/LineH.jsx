import React from 'react'

const LineH = () => {
  return (
    <div className='my-4 w-full border-b-2 border-gray-400'>
      
    </div>
  )
}

export default LineH
